<h1>Obligatorisk oppgave 3</h1>
<h2>Student: Martin Pedersen og <br> Unni Le</h2>
<h3>Brukerfunksjoner</h3>

<ul>
	<li><a href="./registrere-klasse.php">Registrere klasse</a></li>
	<li><a href="./registrere-student.php">Registrere student</a></li>
	<li><a href="./vis-data-registrert.php">Vis data registrert i tabell</a></li>
	<li><a href="./endre-data.php">Endre data i tabell</a></li>
	<li><a href="./slett-data.php">Slett data fra tabell</a></li>
	<li><a href="./find.php">S&oslash;k i tabell</a></li>
</ul>
