<!DOCTYPE html>
<html>
<head>
	<title>OBLIGATORISK OPPGAVE 2 - PHP</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./style.css">

</head>

<body id="index">

<h1>Obligatorisk oppgave 2</h1>
<h2>Student: Martin Pedersen</h2>
<h3>Brukerfunksjoner</h3>

<ul>
	<li><a href="./registrere-klasse.php">Registrere klasse</a></li>
	<li><a href="./vis-klasse.php">Vis alle klasser</a></li>
	<li><a href="./registrere-student.php">Registrere student</a></li>
	<li><a href="./vis-student.php">Vis alle studenter</a></li>
	<li><a href="./vis-klasseliste.php">Vis klasseliste</a></li>
</ul>



<h3>Tekstfiler</h3>
<ul>
<li><a href="http://home.hbv.no/phptemp/882555/klasse.txt";>Klasse.txt</a></li>
<li><a href="http://home.hbv.no/phptemp/882555/student.txt">Student.txt</a></li>
</ul>

</body>
</html>